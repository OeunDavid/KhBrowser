
var config = {
	mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "188.74.210.21",
            port: parseInt(6100)
        },
        bypassList: []
	}
};

chrome.proxy.settings.set({ value: config, scope: "regular" }, function() { });

function callbackFn(details)
{
	return {
		authCredentials:
		{
			username: "ozsomazq",
			password: "naxmjx87buj9"
		}
	};
}

chrome.webRequest.onAuthRequired.addListener(
	callbackFn,

	{ urls:["<all_urls>"] },
    ['blocking']
);